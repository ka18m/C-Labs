﻿namespace Lab3
{
    partial class Lab3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.input_textbox = new System.Windows.Forms.TextBox();
            this.Input_Button = new System.Windows.Forms.Button();
            this.data_label = new System.Windows.Forms.Label();
            this.output_textbox = new System.Windows.Forms.TextBox();
            this.entered_label = new System.Windows.Forms.Label();
            this.Clear_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // input_textbox
            // 
            this.input_textbox.Location = new System.Drawing.Point(15, 62);
            this.input_textbox.Name = "input_textbox";
            this.input_textbox.Size = new System.Drawing.Size(284, 20);
            this.input_textbox.TabIndex = 0;
            // 
            // Input_Button
            // 
            this.Input_Button.Location = new System.Drawing.Point(331, 59);
            this.Input_Button.Name = "Input_Button";
            this.Input_Button.Size = new System.Drawing.Size(75, 23);
            this.Input_Button.TabIndex = 1;
            this.Input_Button.Text = "Enter";
            this.Input_Button.UseVisualStyleBackColor = true;
            this.Input_Button.Click += new System.EventHandler(this.Input_Button_Click);
            // 
            // data_label
            // 
            this.data_label.AutoSize = true;
            this.data_label.Location = new System.Drawing.Point(12, 30);
            this.data_label.Name = "data_label";
            this.data_label.Size = new System.Drawing.Size(87, 13);
            this.data_label.TabIndex = 2;
            this.data_label.Text = "Enter some data:";
            this.data_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // output_textbox
            // 
            this.output_textbox.Location = new System.Drawing.Point(15, 146);
            this.output_textbox.Multiline = true;
            this.output_textbox.Name = "output_textbox";
            this.output_textbox.ReadOnly = true;
            this.output_textbox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.output_textbox.Size = new System.Drawing.Size(284, 251);
            this.output_textbox.TabIndex = 3;
            // 
            // entered_label
            // 
            this.entered_label.AutoSize = true;
            this.entered_label.Location = new System.Drawing.Point(12, 130);
            this.entered_label.Name = "entered_label";
            this.entered_label.Size = new System.Drawing.Size(68, 13);
            this.entered_label.TabIndex = 4;
            this.entered_label.Text = "You entered:";
            // 
            // Clear_Button
            // 
            this.Clear_Button.Location = new System.Drawing.Point(331, 146);
            this.Clear_Button.Name = "Clear_Button";
            this.Clear_Button.Size = new System.Drawing.Size(75, 23);
            this.Clear_Button.TabIndex = 5;
            this.Clear_Button.Text = "Clear";
            this.Clear_Button.UseVisualStyleBackColor = true;
            this.Clear_Button.Click += new System.EventHandler(this.Clear_Button_Click);
            // 
            // Lab3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 466);
            this.Controls.Add(this.Clear_Button);
            this.Controls.Add(this.entered_label);
            this.Controls.Add(this.output_textbox);
            this.Controls.Add(this.data_label);
            this.Controls.Add(this.Input_Button);
            this.Controls.Add(this.input_textbox);
            this.Name = "Lab3";
            this.Text = "Lab3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox input_textbox;
        private System.Windows.Forms.Button Input_Button;
        private System.Windows.Forms.Label data_label;
        private System.Windows.Forms.TextBox output_textbox;
        private System.Windows.Forms.Label entered_label;
        private System.Windows.Forms.Button Clear_Button;
    }
}

